export const config = {
    url: 'https://norma.nomoreparties.space/api'
};

export function getRandom() {
    return Math.random();
};